#include "tasklocalcontroller.h"

#include "manager/database/databasemanager.h"
#include "repository/tasklocalrepository.h"

TaskLocalController::TaskLocalController()
    : TaskController(TaskService(new TaskLocalRepository())) {}
