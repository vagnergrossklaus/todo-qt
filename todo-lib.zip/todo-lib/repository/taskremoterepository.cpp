#include "taskremoterepository.h"

#include "manager/configuration/configurationmanager.h"
#include "manager/network/networkmanager.h"

TaskRemoteRepository::TaskRemoteRepository() {}

QVector<TaskModel *> TaskRemoteRepository::findAll() {
  return {};
}

void TaskRemoteRepository::add(TaskModel *task) {
  Q_UNUSED(task);
}

void TaskRemoteRepository::remove(const int &id) {
  Q_UNUSED(id);
}

void TaskRemoteRepository::edit(TaskModel *task) {
  Q_UNUSED(task);
}
