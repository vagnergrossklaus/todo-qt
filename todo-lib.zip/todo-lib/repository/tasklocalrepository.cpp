#include "tasklocalrepository.h"

#include "manager/database/databasemanager.h"

TaskLocalRepository::TaskLocalRepository() {
}

QVector<TaskModel *> TaskLocalRepository::findAll() {
  return {};
}

void TaskLocalRepository::add(TaskModel *task) {
  Q_UNUSED(task);
}

void TaskLocalRepository::remove(const int &id) {
  Q_UNUSED(id);
}

void TaskLocalRepository::edit(TaskModel *task) {
  Q_UNUSED(task);
}
