#ifndef CONFIGURATIONMANAGER_H
#define CONFIGURATIONMANAGER_H

#include "model/configmodel.h"

class ConfigurationManager {
public:
  static ConfigurationManager &instance();

private:
  ConfigurationManager();

};

#endif // CONFIGURATIONMANAGER_H
