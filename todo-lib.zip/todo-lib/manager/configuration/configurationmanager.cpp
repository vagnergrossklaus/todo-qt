#include "configurationmanager.h"

ConfigurationManager::ConfigurationManager() {}

ConfigurationManager &ConfigurationManager::instance() {
  static ConfigurationManager manager;
  return manager;
}
