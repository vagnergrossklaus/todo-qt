#include "databasemanager.h"

DatabaseManager::DatabaseManager() {
}

DatabaseManager &DatabaseManager::instance() {
  static DatabaseManager manager;
  return manager;
}
