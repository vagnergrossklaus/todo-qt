#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

class DatabaseManager {
public:
  static DatabaseManager &instance();

private:
  DatabaseManager();
};

#endif // DATABASEMANAGER_H
