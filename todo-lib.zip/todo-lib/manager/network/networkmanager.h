#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H

class NetworkManager {
public:
  static NetworkManager &instance();

private:
  NetworkManager();

};

#endif // NETWORKMANAGER_H
