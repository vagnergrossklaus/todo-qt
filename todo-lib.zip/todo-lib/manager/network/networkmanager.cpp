#include "networkmanager.h"

NetworkManager::NetworkManager() {
}

NetworkManager &NetworkManager::instance() {
  static NetworkManager manager;
  return manager;
}
